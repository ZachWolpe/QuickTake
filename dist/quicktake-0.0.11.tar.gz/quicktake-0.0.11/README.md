# QuickTake

Off-the-shelf computer vision ML models. Yolov5, gender and age determination.


## Getting Started

## Resources

## Future

Many sub-modules are in the pipeline. If you wish to contribute, please email me @zachcolinwolpe@gmail.com!