# QuickTake

Off-the-shelf computer vision ML models. Yolov5, gender and age determination.


---
: Zach Wolpe
: zach.wolpe@medibio.com.au
---