

def main():
    print('Launching Quicktake!!')


